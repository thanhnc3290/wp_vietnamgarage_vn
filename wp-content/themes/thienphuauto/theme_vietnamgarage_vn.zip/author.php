<?php 
    echo 'author.php';
?>