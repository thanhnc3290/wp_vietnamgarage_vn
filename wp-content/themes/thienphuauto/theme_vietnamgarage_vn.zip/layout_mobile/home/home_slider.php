<?php
echo do_shortcode('[smartslider3 slider="4"]');
?>