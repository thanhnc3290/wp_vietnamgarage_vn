<?php 
    echo 'full-width.php';

?>