<?php 
    echo 'content-none.php';
?>