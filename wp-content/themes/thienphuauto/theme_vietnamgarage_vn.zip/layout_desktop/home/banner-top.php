<a class="header-top" href="">
    <?php echo do_shortcode('[smartslider3 slider="5"]');?>
</a>