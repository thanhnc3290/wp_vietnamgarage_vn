<div class="group-product-category js-product-load js-product-460 loaded" id="home_midle_banner" data-catid="460" data-cat="boxcat460">
    <div class="banner-category-home d-flex hover-2" id="js-banner-460">
        <?php echo do_shortcode('[metaslider id="58"]'); ?>
        <?php echo do_shortcode('[metaslider id="60"]'); ?>
    </div>
</div>